 ___   __    _  _______  ___   __    _  ___   _______  _______    ______    _______  _______        _______  __   __  _______ 
|   | |  |  | ||       ||   | |  |  | ||   | |       ||       |  |    _ |  |       ||  _    |      |       ||  |_|  ||       |
|   | |   |_| ||    ___||   | |   |_| ||   | |_     _||    ___|  |   | ||  |    ___|| |_|   |      |    ___||       ||    ___|
|   | |       ||   |___ |   | |       ||   |   |   |  |   |___   |   |_||_ |   | __ |       |      |   |___ |       ||   |___ 
|   | |  _    ||    ___||   | |  _    ||   |   |   |  |    ___|  |    __  ||   ||  ||  _   |  ___  |    ___| |     | |    ___|
|   | | | |   ||   |    |   | | | |   ||   |   |   |  |   |___   |   |  | ||   |_| || |_|   ||   | |   |___ |   _   ||   |___ 
|___| |_|  |__||___|    |___| |_|  |__||___|   |___|  |_______|  |___|  |_||_______||_______||___| |_______||__| |__||_______|


(infinitergb.exe)

This file works best on windows 10 home-pro (i only have tested it on windows 10 home) 

This trojan was made in C++ (it may lag the machine a bit)

Created by gdimalwaremaker on youtube

(GitHub.com/forgditestingxorrr) 

hope you enjoy 


hello n17pro3426.
hello PC
hello pankoza
(and more)